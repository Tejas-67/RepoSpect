package com.example.firebasetutorial

import android.app.Application

class app: Application() {
}