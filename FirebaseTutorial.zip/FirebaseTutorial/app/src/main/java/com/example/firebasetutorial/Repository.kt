package com.example.firebasetutorial

import retrofit2.Response

class Repository {

    suspend fun loginUser(name: String, password:String):Response<StringResponse>{
        return RetrofitInstance.api.loginUser(name, password)
    }
}