package com.example.firebasetutorial

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Response

class ViewModel(app: Application, val repo: Repository): AndroidViewModel(app) {

    val userData = MutableLiveData<Resource<StringResponse>>()

    fun checkUser(name: String, password: String){
        viewModelScope.launch{
            userData.postValue(Resource.Loading())
            val response = repo.loginUser(name, password)
            userData.postValue(handleResponse(response))
        }
    }
    private fun handleResponse(response: Response<StringResponse>):Resource<StringResponse>{
        if(response.isSuccessful){
            response.body()?.let {
                return Resource.Success(it)
            }
        }
        return Resource.Error("Error")
    }

}