package com.example.firebasetutorial

import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.DatePicker
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.firebasetutorial.databinding.ActivityMainBinding
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.auth.User
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var database: FirebaseFirestore
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel : ViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModel(app(), Repository())

        viewModel.userData.observe(this@MainActivity, androidx.lifecycle.Observer {
            when(it){
                is Resource.Loading ->{
                    showToast("Loading")
                }
                is Resource.Error->{
                    showToast("Error")
                }
                else-> showToast("Success!")
            }
        })

        binding.button.setOnClickListener {
            viewModel.checkUser(
                binding.name.text.toString(),
                binding.password.text.toString()
            )
        }


    }
    private fun showToast(message: String){
        Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
    }



}