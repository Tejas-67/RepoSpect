package com.example.firebasetutorial

class StringResponse {
    var data: String = ""
}